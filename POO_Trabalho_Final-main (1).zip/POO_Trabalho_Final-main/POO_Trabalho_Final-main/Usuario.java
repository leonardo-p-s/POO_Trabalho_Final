import java.io.Serializable;


public class Usuario implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3225135171213333034L;
	// Atributos
	private String Login;
	private String Nome;
	private String NroCelular;
	private String CPF;
	private String email;
	private String DataNasc;
	private String Sexo;
	private String FormaPagPref;
	
	private int NroCorridas = 0;
	private int NroCorridasAval;				// Nro de notas de avaliação recebidas de motoristas
	private float NotaMediaAval;
	
	private static int VipTH;					// X: Nro de viagens p/ se tornar ClienteVIP
	
	// Construtores
	public Usuario() {};
	public Usuario(String n, String cpf) {
		setNome(n);
		setCPF(cpf);
	}
	public Usuario(String l, String n, String cel, String cpf, String email, String dn, String sex, String fp, int nc) {
		if (n.length() <= 1 || !n.matches("^[\\p{L} ]+$")) {throw new IllegalArgumentException("Nome inválido!");}
		if (!ValidaCPF.isCPF(cpf)) { throw new IllegalArgumentException("CPF inválido!"); }
		setLogin(l);
		setNome(n);
		setNroCelular(cel);
		setCPF(cpf);
		setEmail(email);
		setDataNasc(dn);
		setSexo(sex);
		setFormaPagPref(fp);
		setNroCorridas(nc);
	}
	
	// Getters
	public String getLogin() {
		return Login;}
	public String getNome() {
		return Nome;}
	public String getNroCelular() {
		return NroCelular;}
	public String getCPF() {
		return CPF;}
	public String getEmail() {
		return email;}
	public String getDataNasc() {
		return DataNasc;}
	public String getSexo() {
		return Sexo;}
	public String getFormaPagPref() {
		return FormaPagPref;}
	public int getNroCorridas() {
		return NroCorridas;}
	public float getNotaMediaAval() {
		return NotaMediaAval;}
	public static int getVipTH() {
		return VipTH;}
	public int getNroCorridasAval() {
		return NroCorridasAval;}

	// Setters
	public void setLogin(String login) {
		Login = login;}
	public void setNome(String nome) {
	    if (nome == null || nome.length() <= 1 || !nome.matches("^[\\p{L} ]+$")) {
	        throw new IllegalArgumentException("Nome inválido!"); }
	    this.Nome = nome;}
	public void setNroCelular(String nroCelular) {
		NroCelular = nroCelular;}
	public void setCPF(String cpf) {
	    if (!ValidaCPF.isCPF(cpf)) {
	        throw new IllegalArgumentException("CPF inválido!");}
	    this.CPF = cpf; }
	public void setEmail(String email) {
		this.email = email;}
	public void setDataNasc(String dataNasc) {
		this.DataNasc = dataNasc;}
	public void setSexo(String sexo) {
		this.Sexo = sexo;}
	public void setFormaPagPref(String formaPagPref) {
		this.FormaPagPref = formaPagPref;}
	public void setNroCorridas(int nroCorridas) {
		this.NroCorridas = nroCorridas;}
	public void setNotaMediaAval(float notaMediaAval) {
		this.NotaMediaAval = notaMediaAval;}
	public static void setVipTH(int x) {
		VipTH = x;}
	public void setNroCorridasAval(int nroCorridasAval) {
		this.NroCorridasAval = nroCorridasAval;}
	
	// Métodos
	public void AdicionaCorrida() {
		setNroCorridas(NroCorridas += 1);
	}
	public void AdicionaAval(int Nota) {
		float NotaTotal = NroCorridasAval * NotaMediaAval;
		setNroCorridasAval(NroCorridasAval += 1);
		NotaTotal += Nota;
		setNotaMediaAval(NotaTotal / NroCorridasAval);		// Atualiza nota média
	}
	@Override
	public String toString() {
		return "Usuario [Login=" + Login + ", Nome=" + Nome + ", NroCelular=" + NroCelular + ", CPF=" + CPF + ", email="
				+ email + ", DataNasc=" + DataNasc + ", Sexo=" + Sexo + ", FormaPagPref=" + FormaPagPref
				+ ", NroCorridas=" + NroCorridas + ", NroCorridasAval=" + NroCorridasAval + ", NotaMediaAval="
				+ NotaMediaAval + "]";
	}

}
