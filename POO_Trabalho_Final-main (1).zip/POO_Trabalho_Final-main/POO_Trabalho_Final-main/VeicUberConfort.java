
public class VeicUberConfort extends Veiculo {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7254275198524187676L;
	// Attributes
	private boolean PossuiEspacoExtra;
	private boolean PossuiBancRecl;
	private boolean PossuiACDualZone;
	
	private static float TarifaMinima;
	private static float CustoPorKm;
	
	// Constructors
	public VeicUberConfort(Motorista condut, String marca, String mod, int a, String p, String vn, String c, int cap, boolean ee, boolean br, boolean acdz) {
		super(condut, marca, mod, a, p, vn, c, cap);
		setPossuiEspacoExtra(ee);
		setPossuiBancRecl(br);
		setPossuiACDualZone(acdz);
		
	}
	// Getters and Setters
	public boolean isPossuiEspacoExtra() {return PossuiEspacoExtra;}
	public void setPossuiEspacoExtra(boolean possuiEspacoExtra) {PossuiEspacoExtra = possuiEspacoExtra;}
	public boolean isPossuiBancRecl() {return PossuiBancRecl;}
	public void setPossuiBancRecl(boolean possuiBancRecl) {PossuiBancRecl = possuiBancRecl;}
	public boolean isPossuiACDualZone() {return PossuiACDualZone;}
	public void setPossuiACDualZone(boolean possuiACDualZone) {PossuiACDualZone = possuiACDualZone;}
	
	// Methods
	public float CalculaCustoViagem(float DistKm) {
		float CustoBasico = (DistKm * CustoPorKm) + TarifaMinima;
		if(PossuiACDualZone || PossuiEspacoExtra)
			CustoBasico = CustoBasico + (2 * TarifaMinima);
		return CustoBasico;
	}
}
