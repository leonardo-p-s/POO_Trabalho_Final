//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;

/**public class Persist {
	public static boolean gravar(Object o, String arquivo) {
		try {
			FileOutputStream arquivoGrav = new FileOutputStream(arquivo);
			ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGrav);
			objGravar.writeObject(o);
			objGravar.flush();
			objGravar.close();
			arquivoGrav.flush();
			arquivoGrav.close();
			return true;
		}
		catch (Exception e) {
			return false; 
	    }
	}



	public static Object recuperar(String arquivo) {
		Object obj = null;
		FileInputStream arquivoLeitura = null;
		ObjectInputStream objLeitura = null;
		try {
			arquivoLeitura = new FileInputStream(arquivo);
			objLeitura = new ObjectInputStream(arquivoLeitura);
			obj = objLeitura.readObject();
			objLeitura.close();
			arquivoLeitura.close();
		}
		catch(Exception e) {
			return null;
		}
		return obj;
	}
}**/

import java.io.*;

public class Persist {
    
    // Método para gravar
    public static boolean gravar(Object obj, String arquivo) {
        FileOutputStream arquivoGrav = null;
        ObjectOutputStream objGrav = null;
        
        try {
            arquivoGrav = new FileOutputStream(arquivo);
            objGrav = new ObjectOutputStream(arquivoGrav);
            objGrav.writeObject(obj);
            objGrav.flush();
            return true;
        } catch (Exception e) {
            e.printStackTrace(); //  Mostra o erro no console
            return false;
        } finally {
            // Fechamento seguro dos recursos
            try {
                if (objGrav != null) objGrav.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (arquivoGrav != null) arquivoGrav.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    // Método para recuperar
    public static Object recuperar(String arquivo) {
        FileInputStream arquivoLeitura = null;
        ObjectInputStream objLeitura = null;
        
        try {
            arquivoLeitura = new FileInputStream(arquivo);
            objLeitura = new ObjectInputStream(arquivoLeitura);
            Object obj = objLeitura.readObject();
            return obj;
        } catch (Exception e) {
            e.printStackTrace(); // Mostra o erro no console
            return null;
        } finally {
            // Fechamento seguro dos recursos
            try {
                if (objLeitura != null) objLeitura.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (arquivoLeitura != null) arquivoLeitura.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
