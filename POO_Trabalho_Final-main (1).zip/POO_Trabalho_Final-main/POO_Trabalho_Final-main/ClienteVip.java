
public class ClienteVip extends Usuario{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8260811414323175643L;
	// Atributos
	private float PorcDesconto;
	
	// Constructors
	public ClienteVip(String l, String n, String cel, String cpf, String email, String dn, String sex, String fp, int nc) {
		super(l, n, cel, cpf, email, dn, sex, fp, nc);
		setPorcDesconto(nc);
	}
    
    public void setPorcDesconto(float porcDesconto) {
    	    this.PorcDesconto = porcDesconto;
        }
	public float getPorcDesconto() {
        	return PorcDesconto;
        	}

	public void setPorcDesconto(int nroCorridas) {
		if(nroCorridas > super.getVipTH() && nroCorridas < 1.2 * super.getVipTH())
			PorcDesconto = 0.05f;
		if(nroCorridas >= 1.2 * super.getVipTH() && nroCorridas < 1.5 * super.getVipTH())
			PorcDesconto = 0.075f;
		if(nroCorridas >= 1.5 * super.getVipTH())
			PorcDesconto = 0.1f;
	}
}
